import matplotlib.pyplot as plt

plt.plot([500,550,600,650], [0.275,0.274,0.268,0.270],  'ro')
plt.axis([500, 1200, 0, 1])
plt.show()
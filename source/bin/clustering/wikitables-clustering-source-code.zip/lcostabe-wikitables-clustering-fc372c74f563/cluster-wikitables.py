__author__ = 'Luca Costabello <luca.costabello@ie.fujitsu.com>'

"""
===========================================================
Wikitables K-Means K estimation
===========================================================
"""
print(__doc__)

from time import time
import numpy as np
import csv

from sklearn import metrics
from sklearn.cluster import KMeans
from sklearn.preprocessing import scale
from scipy.sparse import *
import matplotlib.pyplot as plt
import pandas as pd
from collections import defaultdict

def extract(fname):
  """
  extracts entries from a csv file
  input: fname (str) -- path to csv file
  output: generator<(int, int, float)> -- generator
          producing 3-tuple containing (row-index, column-index, data)
  """

  global glob_findex
  for (rindex,row) in enumerate(csv.reader(open(fname))):
    for (cindex, data) in enumerate(row):
        inner = data.split('=')
        value = float(inner[1])
        if value != 0:
            token_id = inner[0]
            if features.has_key(token_id):
                findex = features.get(token_id)
            else:
                findex = glob_findex
                features[token_id] = findex
                glob_findex = glob_findex + 1
            yield (rindex, findex, value)


def get_dimensions(fname):
  """
  determines the dimension of a csv file
  input: fname (str) -- path to csv file
  output: (nrows, ncols) -- tuple containing row x col data
  """
  rowgen = (row for row in csv.reader(open(fname)))
  # compute col size
  colsize = len(rowgen.next())
  # compute row size
  rowsize = 1 + sum(1 for row in rowgen)
  return (rowsize, colsize)





# # results file dump
# results_file = 'results/k-estimation-' + batch + '-silh.csv'
# with open(results_file, "w") as out_file:
#         out_file.write('vector-file,cluster-number,time,inertia,silhouette\n')
# out_file.close()


# protect parallel k-means execution
if __name__ == '__main__':

    # minimum size of a cluster for printout
    threshold = 3

    # Vector file path
    base = "vectors"
    batch = "split_1_refined"

    vectors_file_path = base + "/" + batch + '/vectors-split_1_refined-ALL-WEIGHT-1.csv'
    table_dictionary_path = base + "/" + batch + '/table_dictionary.txt'
    results_file = 'results/' + batch + '-kmeans-results-bigger-than-' + str(threshold) + '.txt'

    # obtain dimensions of data
    (rdim, cdim) = get_dimensions(vectors_file_path)

    # allocate a lil_matrix of size (rdim by cdim)
    # note: lil_matrix is used since we be modifying
    #       the matrix a lot.
    S = lil_matrix((rdim, 5000))


    # df = pd.read_csv(table_dictionary_path)
    # cols = [col for col in df.columns if col not in ['tableID']]
    # df2 = df[cols]
    with open(table_dictionary_path) as f:
        table_details_list = f.readlines()

    clusters = defaultdict(list)

    # features dictionary
    features = dict()
    glob_findex = 0

    # add data to S
    for (i,j,d) in extract(vectors_file_path):
      S[i,j] = d


    k = 1900
    estimator = KMeans(init='k-means++', n_clusters=k, n_jobs= -1)
    t0 = time()
    cluster_associations = estimator.fit_predict(S.tocsr())
    elapsed = time() - t0
    for idx, val in enumerate(cluster_associations):
        clusters[val].append(idx)





    # === dumps results to file
    with open(results_file, "w") as out_file:
        for clusterID, tableList in clusters.iteritems():
          if len(tableList) >= threshold:
              out_file.write("Cluster-" + (str(clusterID) + "\n\t"))
              for tableID in tableList:
                out_file.write((str(table_details_list[tableID])) + "\t")
              out_file.write("\n\n")
    out_file.close()
    print("cluster count: %d. Elapsed time: %d" % (len(clusters), elapsed))


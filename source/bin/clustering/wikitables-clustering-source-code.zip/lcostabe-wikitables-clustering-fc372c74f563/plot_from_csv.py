__author__ = 'CostabelloL'

"""
===========================================================
Scatterplot for cluster analysis results
===========================================================
"""
print(__doc__)

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np



# Batch run params
k_range_start = 1300
k_range_stop = 3500
k_range_step = 100


# Vector file path
base = "results"
batch = 'split_1_refined'
results_file = 'k-estimation-split_1_refined-silh-features'
results_file_path = base + "/" + results_file + '.csv'

df = pd.read_csv(results_file_path)
saved_column = df.silhouette
silhouette_index_list = df.silhouette.values


# Plot
name = 'plots/' + batch + '-silhouette-features-estimation.png'

# create x axis values
x_values = []
for i in range(k_range_start, k_range_stop + k_range_step, k_range_step):
    x_values.append(i)

plt.plot(x_values, silhouette_index_list, linestyle='--', marker='o')
plt.xlabel('Number of Clusters')
plt.ylabel('Silhouette Coefficient')
plt.axis([k_range_start, k_range_stop, 0, 1.05])
plt.legend(['Tokens + Column count + Lexical', 'Tokens + Column count',
            'Tokens only', 'Lexical Only'],
           loc='lower right', prop={'size':8})


m = max(silhouette_index_list)
for i, val in enumerate(silhouette_index_list):
    if val == m:
        x_annotation = x_values[i]

plt.plot((x_annotation, x_annotation), (0, 1.05), 'k:')
plt.annotate('Optimal = ' + str(x_annotation), xy=(x_annotation, .3 ),
                        xytext=(x_annotation + 50,.4),
                        arrowprops=dict(facecolor='black', shrink=0.1, width=1, headwidth=4))
plt.title('K Estimation (Wikipedia Split 1)')
plt.savefig(name)
plt.show()

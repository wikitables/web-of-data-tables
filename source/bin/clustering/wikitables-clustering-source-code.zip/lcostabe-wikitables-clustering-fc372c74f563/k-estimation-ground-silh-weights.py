__author__ = 'Luca Costabello <luca.costabello@ie.fujitsu.com>'

"""
===========================================================
Wikitables K-Means K estimation
(Silhouette coefficient with
different weights for column count and tokens.)
===========================================================
"""
print(__doc__)

from time import time
import numpy as np
import csv

from sklearn import metrics
from sklearn.cluster import KMeans
from sklearn.preprocessing import scale
from scipy.sparse import *
import matplotlib.pyplot as plt

def extract(fname):
  """
  extracts entries from a csv file
  input: fname (str) -- path to csv file
  output: generator<(int, int, float)> -- generator
          producing 3-tuple containing (row-index, column-index, data)
  """

  global glob_findex
  for (rindex,row) in enumerate(csv.reader(open(fname))):
    for (cindex, data) in enumerate(row):
        inner = data.split('=')
        value = float(inner[1])
        if value != 0:
            token_id = inner[0]
            if features.has_key(token_id):
                findex = features.get(token_id)
            else:
                findex = glob_findex
                features[token_id] = findex
                glob_findex = glob_findex + 1
            yield (rindex, findex, value)


def get_dimensions(fname):
  """
  determines the dimension of a csv file
  input: fname (str) -- path to csv file
  output: (nrows, ncols) -- tuple containing row x col data
  """
  rowgen = (row for row in csv.reader(open(fname)))
  # compute col size
  colsize = len(rowgen.next())
  # compute row size
  rowsize = 1 + sum(1 for row in rowgen)
  return (rowsize, colsize)



def bench_k_means(estimator, name, data):
    global results_file
    global vectors_file
    t0 = time()
    estimator.fit(data)
    silhouette_index = metrics.silhouette_score(data, estimator.labels_,
                                      metric='euclidean',
                                      sample_size=rdim)
    print('% 5s   %.2fs    %i   %.3f'
          % (name,
             (time() - t0),
             estimator.inertia_,
             silhouette_index))
    with open(results_file, "a") as out_file:
        out_file.write(vectors_file + ',' + str(name) + ',' + str((time() - t0))
                       + ',' + str(estimator.inertia_)+ ','
                       + str(silhouette_index) + '\n')
    out_file.close()
    return silhouette_index



def cluster_range(start, end, step):
    while start <= end:
        yield start
        start += step

# protect parallel k-means execution
if __name__ == '__main__':

    # Vector file path
    base = "vectors"
    batch = "ground_truth"

    vectors_files = ['vectors-ground-ALL-TOK=1-COL=1',
                     'vectors-ground-ALL-TOK=2-COL=2',
                     'vectors-ground-ALL-TOK=4-COL=4',
                     'vectors-ground-ALL-TOK=8-COL=8',
                     'vectors-ground-ALL-TOK=16-COL=16',
                     'vectors-ground-ALL-TOK=32-COL=32']

    # results
    run_results = []

    # results file dump
    results_file = 'results/k-estimation-ground-silh-weights.csv'
    with open(results_file, "w") as out_file:
            out_file.write('vector-file,cluster-number,time,inertia,silhouette\n')
    out_file.close()

    # iterate over different vector files
    for vectors_file in vectors_files:

        vectors_file_path = base + "/" + batch + "/" + vectors_file + '.csv'

        # Batch run params
        k_range_start = 2
        k_range_stop = 25
        k_range_step = 1

        # features dictionary
        features = dict()

        glob_findex = 0

        # obtain dimensions of data
        (rdim, cdim) = get_dimensions(vectors_file_path)

        # allocate a lil_matrix of size (rdim by cdim)
        # note: lil_matrix is used since we be modifying
        #       the matrix a lot.
        S = lil_matrix((rdim, 5000))

        # add data to S
        for (i,j,d) in extract(vectors_file_path):
          S[i,j] = d


        print('% 5s' % 'init'
              '   time  inertia     silhouette')

        # execute cluster analysis

        # keep tracks of silhouette scores for plotting
        silhouette_index_list = []
        for x in cluster_range(k_range_start, k_range_stop, k_range_step):
            silhouette_index_list.append(bench_k_means(KMeans(init='k-means++', n_clusters=x, n_jobs= 1),
                          name= x , data=S.tocsr()))

        run_results.append(silhouette_index_list)


    # create x axis values
    x_values = []
    for i in range(k_range_start, k_range_stop + k_range_step, k_range_step):
        x_values.append(i)




# ====== plots out of multi-threaded section

# Silhouette plot
name = 'plots/' + batch + '-silhouette-weight-estimation.png'
for series in run_results:
    plt.plot(x_values, series, linestyle='--', marker='o')
plt.xlabel('Number of Clusters')
plt.ylabel('Silhouette Coefficient')
plt.axis([k_range_start, k_range_stop, 0, 1.05])
plt.legend(['Weight = 1', 'Weight = 2','Weight = 4', 'Weight = 8', 'Weight = 16', 'Weight = 32'],
           loc='lower right', prop={'size':8})

# annotate graph w/ vertical line on ground truth clustering value
ground_truth = 18
plt.plot((ground_truth, ground_truth), (0, 1.05), 'k-')
plt.annotate('Ground Truth = ' + str(ground_truth), xy=(ground_truth, .3 ),
                        xytext=(ground_truth + 1,.4),
                        arrowprops=dict(facecolor='black', shrink=0.1, width=1, headwidth=4))
# # annotate graph w/ vertical line on optimal estimated clustering value
# x_annotation = x_values[silhouette_index_list.index(max(silhouette_index_list))]
# plt.plot((x_annotation, x_annotation), (0, 1.05), 'k-')
# plt.annotate('Optimal = ' + str(x_annotation), xy=(x_annotation, .8 ),
#                         xytext=(x_annotation + 1,.9),
#                         arrowprops=dict(facecolor='black', shrink=0.1, width=1, headwidth=4))
plt.title('Clustering Performance (Bag of Words/Column Count Weights)')
plt.savefig(name)
plt.show()


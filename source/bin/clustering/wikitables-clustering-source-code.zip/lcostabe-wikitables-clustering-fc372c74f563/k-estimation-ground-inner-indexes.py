__author__ = 'Luca Costabello <luca.costabello@ie.fujitsu.com>'

"""
===========================================================
Wikitables K-Means K estimation
===========================================================
"""
print(__doc__)

from time import time
import numpy as np
import csv

from sklearn import metrics
from sklearn.cluster import KMeans
from sklearn.preprocessing import scale
from scipy.sparse import *
import matplotlib.pyplot as plt


def extract(fname):
  """
  extracts entries from a csv file
  input: fname (str) -- path to csv file
  output: generator<(int, int, float)> -- generator
          producing 3-tuple containing (row-index, column-index, data)
  """

  global glob_findex
  for (rindex,row) in enumerate(csv.reader(open(fname))):
    for (cindex, data) in enumerate(row):
        inner = data.split('=')
        value = float(inner[1])
        if value != 0:
            token_id = inner[0]
            if features.has_key(token_id):
                findex = features.get(token_id)
            else:
                findex = glob_findex
                features[token_id] = findex
                glob_findex = glob_findex + 1
            yield (rindex, findex, value)


def get_dimensions(fname):
  """
  determines the dimension of a csv file
  input: fname (str) -- path to csv file
  output: (nrows, ncols) -- tuple containing row x col data
  """
  rowgen = (row for row in csv.reader(open(fname)))
  # compute col size
  colsize = len(rowgen.next())
  # compute row size
  rowsize = 1 + sum(1 for row in rowgen)
  return (rowsize, colsize)



def bench_k_means(estimator, name, data, labels):
    global quality_measures
    t0 = time()
    estimator.fit(data)
    quality_measures['silhouette'] = metrics.silhouette_score(data, estimator.labels_,
                                      metric='euclidean',
                                      sample_size=rdim)
    # inner metrics
    test = metrics.homogeneity_score(labels, estimator.labels_)
    quality_measures['homogeneity_score'] = metrics.homogeneity_score(labels, estimator.labels_),
    quality_measures['completeness_score'] = metrics.completeness_score(labels, estimator.labels_),
    quality_measures['v_measure_score'] = metrics.v_measure_score(labels, estimator.labels_),
    quality_measures['adjusted_rand_score'] = metrics.adjusted_rand_score(labels, estimator.labels_),
    quality_measures['adjusted_mutual_info_score'] = metrics.adjusted_mutual_info_score(labels,  estimator.labels_),
    print('% 9s   %.2fs    %i   %.3f   %.3f   %.3f   %.3f   %.3f    %.3f '
          % (name,
             (time() - t0),
             estimator.inertia_,
             quality_measures['homogeneity_score'][0],
             quality_measures['completeness_score'][0],
             quality_measures['v_measure_score'][0],
             quality_measures['adjusted_rand_score'][0],
             quality_measures['adjusted_mutual_info_score'][0],
             quality_measures['silhouette']
            )
    )

    with open(results_file, "a") as out_file:
        out_file.write(vectors_file + ',' + str(name) + ',' + str((time() - t0))
                       + ',' + str(estimator.inertia_)+ ','
                       + ',' + str(quality_measures['homogeneity_score'][0])+ ','
                       + ',' + str(quality_measures['completeness_score'][0])+ ','
                       + ',' + str(quality_measures['v_measure_score'][0])+ ','
                       + ',' + str(quality_measures['adjusted_rand_score'][0])+ ','
                       + ',' + str(quality_measures['adjusted_mutual_info_score'][0])+ ','
                       + str(quality_measures['silhouette']) + '\n')
    out_file.close()



    return quality_measures



def cluster_range(start, end, step):
    while start <= end:
        yield start
        start += step

# protect parallel k-means execution
if __name__ == '__main__':

    # Vector file path
    base = "vectors"
    batch = "ground_truth"
    vectors_file = 'vectors-ground-ALL-TOK=1-COL=1'
    vectors_file_path = base + "/" + batch + "/" + vectors_file + '.csv'






    # Ground truth vector labels (see resources/labeled-clusters-ground-truth.txt)
    labels = [1,2,3,3,3,4,5,1,6,6,7,9,8,18,9,8,10,9,8,11,11,11,12,9,8,9,8,1,17,15,16,16,13,13,13,14]


    # Batch run params
    k_range_start = 2
    k_range_stop = 25
    k_range_step = 1

    # features dictionary
    features = dict()

    # quality index measures dictionary
    quality_measures = dict()

    glob_findex = 0

    # obtain dimensions of data
    (rdim, cdim) = get_dimensions(vectors_file_path)

    # allocate a lil_matrix of size (rdim by cdim)
    # note: lil_matrix is used since we be modifying
    #       the matrix a lot.
    S = lil_matrix((rdim, 5000))

    # add data to S
    for (i,j,d) in extract(vectors_file_path):
      S[i,j] = d


    print('% 9s' % 'init'
          '         time  inertia    homo   compl  v-meas     ARI   AMI    silhouette')
    # results file dump
    results_file = 'results/k-estimation-ground-inner-indexes.csv'
    with open(results_file, "w") as out_file:
            out_file.write('vector-file,cluster-number,time,inertia,homogeneity_score,'
                           'completeness_score,v_measure_score,adjusted_rand_score,'
                           'adjusted_mutual_info_score,silhouette\n')
    out_file.close()


    # execute cluster analysis and quality metrics computation
    homogeneity_score_list = []
    completeness_score_list = []
    v_measure_score_list = []
    adjusted_rand_score_list = []
    adjusted_mutual_info_score_list = []
    silhouette_index_list = []
    for x in cluster_range(k_range_start, k_range_stop, k_range_step):
        estimator = KMeans(init='k-means++', n_clusters=x, n_jobs= 1)
        quality_measures_for_x = bench_k_means(estimator,name= x , data=S.tocsr(), labels=labels)
        homogeneity_score_list.append(quality_measures_for_x['homogeneity_score'][0])
        completeness_score_list.append(quality_measures_for_x['completeness_score'][0])
        v_measure_score_list.append(quality_measures_for_x['v_measure_score'][0])
        adjusted_rand_score_list.append(quality_measures_for_x['adjusted_rand_score'][0])
        adjusted_mutual_info_score_list.append(quality_measures_for_x['adjusted_mutual_info_score'][0])
        silhouette_index_list.append(quality_measures_for_x['silhouette'])



    # create x axis values for plotting
    x_values = []
    for i in range(k_range_start, k_range_stop + k_range_step, k_range_step):
        x_values.append(i)



# ====== plots must stay out of multi-threaded section

# Quality measures plot
name = 'plots/' + batch + '-mixed-quality-measures-ground-truth.png'
# silhouette
plt.plot(x_values, silhouette_index_list, linestyle='--', marker='o')
# homogeneity_score
plt.plot(x_values, homogeneity_score_list, linestyle='--', marker='o')
# completeness_score
plt.plot(x_values, completeness_score_list, linestyle='--', marker='o')
# v_measure_score
plt.plot(x_values, v_measure_score_list, linestyle='--', marker='o')
# adjusted_rand_score
plt.plot(x_values, adjusted_rand_score_list, linestyle='--', marker='o')
# adjusted_mutual_info_score
plt.plot(x_values, adjusted_mutual_info_score_list, linestyle='--', marker='o')

plt.axis([k_range_start, k_range_stop, 0, 1.05])
plt.xlabel('Number of Clusters')
plt.ylabel('Value of Quality Coefficient')
plt.legend(['Silhouette', 'Homogeneity score',
            'Completeness score', 'V-measure score',
            'Adjusted rand score', 'Adjusted mutual info'],
           loc='lower right', prop={'size':8})


# annotate graph w/ vertical line on ground truth clustering value
ground_truth = 18
plt.plot((ground_truth, ground_truth), (0, 1.05), 'k-')

x_annotation = x_values[silhouette_index_list.index(max(silhouette_index_list))]
plt.annotate('Ground Truth = ' + str(ground_truth), xy=(ground_truth, .3 ),
                        xytext=(ground_truth + 1,.4),
                        arrowprops=dict(facecolor='black', shrink=0.1, width=1, headwidth=4))
plt.title('Clustering Performance (Multiple Quality Metrics)')
plt.savefig(name)
plt.show()

